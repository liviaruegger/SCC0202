Arquivo zip gerado em: 09/10/2021 22:33:33 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 6