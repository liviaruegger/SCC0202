Arquivo zip gerado em: 06/12/2021 12:25:55 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 10