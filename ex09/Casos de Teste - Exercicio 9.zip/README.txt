Arquivo zip gerado em: 14/11/2021 16:24:31 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 9