Arquivo zip gerado em: 21/09/2021 11:30:13 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 1