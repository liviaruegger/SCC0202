Arquivo zip gerado em: 13/12/2021 23:39:06 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Projeto 2 - Árvores Treaps